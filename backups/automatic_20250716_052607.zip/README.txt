Local Backup
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━
Created: 2025-07-16 05:26:07
User ID: 384692013855145993
Type: Automatic
Contains: All SQLite database files
━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━━

To restore:
1. Extract this ZIP file
2. Replace your db/ folder contents with these files
3. Restart the bot

🤖 WOS Discord Bot Backup System
